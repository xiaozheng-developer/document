package com.huawei.task;

import com.android.build.gradle.AppExtension;
import com.android.build.gradle.api.ApplicationVariant;
import com.android.build.gradle.api.BaseVariantOutput;
import com.huawei.extension.PluginExtension;

import org.gradle.api.Action;
import org.gradle.api.DefaultTask;
import org.gradle.api.Project;
import org.gradle.api.tasks.Input;
import org.gradle.api.tasks.TaskAction;
import org.gradle.process.ExecResult;
import org.gradle.process.ExecSpec;

import java.io.File;

import javax.inject.Inject;

public class TestPluginTask extends DefaultTask {

    @Input
    private String string;

    @Inject
    public TestPluginTask(String string) {
        this.string = string;
    }

    @TaskAction
    public void test() {
        Project project = getProject();
        PluginExtension byType = project.getExtensions().getByType(PluginExtension.class);
        System.out.println(byType.getName());
        System.out.println(string);
        ExecResult exec = getProject().exec(new Action<ExecSpec>() {
            @Override
            public void execute(ExecSpec execSpec) {
                execSpec.commandLine("java", "-version");
            }
        });
        System.out.println(exec);

    }
}
