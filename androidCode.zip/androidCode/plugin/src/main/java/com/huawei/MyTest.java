package com.huawei;

import com.android.build.gradle.AppExtension;
import com.android.build.gradle.api.ApplicationVariant;
import com.android.build.gradle.api.BaseVariantOutput;
import com.huawei.extension.PluginExtension;
import com.huawei.task.TestPluginTask;

import org.gradle.api.Action;
import org.gradle.api.Plugin;
import org.gradle.api.Project;
import org.gradle.api.Task;

import java.io.File;

public class MyTest implements Plugin<Project> {
    @Override
    public void apply(Project project) {
        // 添加拓展属性
        PluginExtension testPlugin = project.getExtensions().create("testPlugin", PluginExtension.class);
        project.getTasks().create("testPluginTask", TestPluginTask.class, "aa");

        // 插件配置完成加载配置属性
        project.afterEvaluate(pro -> {
            System.out.println(testPlugin.getName());
            System.out.println("==============" + pro.getExtensions().getByType(PluginExtension.class).getName());
            // 获取android拓展
            AppExtension appExtension = project.getExtensions().getByType(AppExtension.class);
            // 获取变体集合
            appExtension.getApplicationVariants().all(new Action<ApplicationVariant>() {
                /**
                 *
                 * @param applicationVariant 变体
                 */
                @Override
                public void execute(ApplicationVariant applicationVariant) {
                    // 获取变体输出
                    applicationVariant.getOutputs().all(new Action<BaseVariantOutput>() {

                        /**
                         *
                         * @param baseVariantOutput 变体输出
                         */
                        @Override
                        public void execute(BaseVariantOutput baseVariantOutput) {
                            // 获取生成的apk
                            File outputFile = baseVariantOutput.getOutputFile();
                            // 获取apk名
                            System.out.println("file name: " + outputFile.getAbsoluteFile());
                            // 获取变体名
                            String name = baseVariantOutput.getName();
                            System.out.println("变体名为: " + name);
                            project.getTasks().create("Test" + name, TestPluginTask.class,"aa");

                        }
                    });
                }
            });
        });
    }
}
